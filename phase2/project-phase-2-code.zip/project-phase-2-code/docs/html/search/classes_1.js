var searchData=
[
  ['login_5fsession_5fdata_5ft_76',['login_session_data_t',['../structlogin__session__data__t.html',1,'']]]
];
