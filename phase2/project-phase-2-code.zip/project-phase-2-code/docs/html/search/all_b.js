var searchData=
[
  ['safe_5ffd_5fmessage_60',['safe_fd_message',['../login_8c.html#ad2baf07136f88cf3bc4b2c924ab4dfb7',1,'login.c']]],
  ['safe_5fmemcpy_61',['safe_memcpy',['../account_8c.html#a4c5202e546fdb384f07beb02bfb03c61',1,'account.c']]],
  ['scanf_62',['scanf',['../banned_8h.html#a9d178d8ab459cd19f1a1749b60af46ca',1,'banned.h']]],
  ['session_5finvalid_5faccount_5fid_63',['SESSION_INVALID_ACCOUNT_ID',['../login_8h.html#a81b97632a0371e8f112dc0dde824438c',1,'login.h']]],
  ['session_5fstart_64',['session_start',['../structlogin__session__data__t.html#ac012c028b98f9bbecbdffede4b7f2c39',1,'login_session_data_t']]],
  ['stderr_65',['stderr',['../banned_8h.html#a5ce35bd5ba5021fd3b2e951e8f497656',1,'banned.h']]],
  ['stdin_66',['stdin',['../banned_8h.html#aaca70138f0cb63ddb026921afc635179',1,'banned.h']]],
  ['stdout_67',['stdout',['../banned_8h.html#a0c0ef221f95f64e8632451312fd18cc8',1,'banned.h']]],
  ['stubs_2ec_68',['stubs.c',['../stubs_8c.html',1,'']]]
];
