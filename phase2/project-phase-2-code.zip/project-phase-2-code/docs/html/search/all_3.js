var searchData=
[
  ['cits3007_5fpermissive_24',['CITS3007_PERMISSIVE',['../stubs_8c.html#ae2297ea00e0fa42d38464d41b39124a1',1,'stubs.c']]]
];
