var searchData=
[
  ['alloca_135',['alloca',['../banned_8h.html#a467fdb207fabdbb103dbc08d3f5ca58e',1,'banned.h']]]
];
