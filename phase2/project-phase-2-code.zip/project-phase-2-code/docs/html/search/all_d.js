var searchData=
[
  ['unban_5ftime_70',['unban_time',['../structaccount__t.html#adef6c7da11348fae71e681e76ca364de',1,'account_t']]],
  ['user_5fid_5flength_71',['USER_ID_LENGTH',['../account_8h.html#aa5003f2775a84bf63e85607f1550facf',1,'account.h']]],
  ['userid_72',['userid',['../structaccount__t.html#a90fb8cc909b8ab104fb45e8de4038b4e',1,'account_t']]]
];
