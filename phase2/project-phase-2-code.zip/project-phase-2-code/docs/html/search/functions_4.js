var searchData=
[
  ['validate_5fbirthdate_105',['validate_birthdate',['../account_8c.html#a321cffe074d3dcc80ab4fe7e6abfb503',1,'account.c']]],
  ['validate_5femail_106',['validate_email',['../account_8c.html#ac6570ef99f768b5ae122a7bc62524885',1,'account.c']]]
];
