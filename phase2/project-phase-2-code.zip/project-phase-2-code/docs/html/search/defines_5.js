var searchData=
[
  ['fprintf_139',['fprintf',['../banned_8h.html#aab6e63106cf29e5160e5c2d63db86d27',1,'banned.h']]],
  ['fscanf_140',['fscanf',['../banned_8h.html#a3ce24f3b2b0397c89edc3a7209e48dcc',1,'banned.h']]]
];
