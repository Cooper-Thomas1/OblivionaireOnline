var searchData=
[
  ['printf_143',['printf',['../banned_8h.html#a3cb9f0894fab1c8fbb0753c9c7c2a8d9',1,'banned.h']]]
];
