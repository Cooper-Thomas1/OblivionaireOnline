var searchData=
[
  ['banned_2eh_21',['banned.h',['../banned_8h.html',1,'']]],
  ['birthdate_22',['birthdate',['../structaccount__t.html#af3655f259ff0f7f00f119ba4280d6ce5',1,'account_t']]],
  ['birthdate_5flength_23',['BIRTHDATE_LENGTH',['../account_8h.html#a1344b712a36e9646d2e7fbe15ea2bcda',1,'account.h']]]
];
