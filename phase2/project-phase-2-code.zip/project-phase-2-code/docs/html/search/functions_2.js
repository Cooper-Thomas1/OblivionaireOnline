var searchData=
[
  ['log_5fmessage_102',['log_message',['../logging_8h.html#acfd97170722882e39e608d3486f367b4',1,'log_message(log_level_t level, const char *fmt,...):&#160;stubs.c'],['../stubs_8c.html#acfd97170722882e39e608d3486f367b4',1,'log_message(log_level_t level, const char *fmt,...):&#160;stubs.c']]]
];
