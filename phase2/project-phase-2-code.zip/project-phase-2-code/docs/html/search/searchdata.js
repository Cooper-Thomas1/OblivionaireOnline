var indexSectionsWithContent =
{
  0: "_abcdefhilpstuv",
  1: "al",
  2: "abdlst",
  3: "ahlsv",
  4: "abelpsu",
  5: "i",
  6: "l",
  7: "l",
  8: "_abcefhipsu"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Macros"
};

