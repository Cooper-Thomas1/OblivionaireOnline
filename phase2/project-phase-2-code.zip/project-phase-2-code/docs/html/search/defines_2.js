var searchData=
[
  ['birthdate_5flength_136',['BIRTHDATE_LENGTH',['../account_8h.html#a1344b712a36e9646d2e7fbe15ea2bcda',1,'account.h']]]
];
