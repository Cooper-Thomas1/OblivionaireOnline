var searchData=
[
  ['safe_5ffd_5fmessage_103',['safe_fd_message',['../login_8c.html#ad2baf07136f88cf3bc4b2c924ab4dfb7',1,'login.c']]],
  ['safe_5fmemcpy_104',['safe_memcpy',['../account_8c.html#a4c5202e546fdb384f07beb02bfb03c61',1,'account.c']]]
];
